(function() {
  $(document).ready(function() {});

}).call(this);
